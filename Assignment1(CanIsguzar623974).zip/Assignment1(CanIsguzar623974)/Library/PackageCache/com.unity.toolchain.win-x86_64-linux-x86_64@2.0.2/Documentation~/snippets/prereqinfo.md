**Note**: You only need to install the toolchain package. The package manager installs dependent packages automatically.
For an overview of Unity sysroot packages, see [Unity Sysroot Package documentation](https://docs.unity3d.com/Packages/com.unity.sysroot@0.1/manual/index.html).

Before you install your chosen package, make sure you have the Linux-IL2CPP module installed for your editor. For further information about using modules, see [Adding modules to the Unity Editor](https://docs.unity3d.com/Manual/GettingStartedAddingEditorComponents.html).
