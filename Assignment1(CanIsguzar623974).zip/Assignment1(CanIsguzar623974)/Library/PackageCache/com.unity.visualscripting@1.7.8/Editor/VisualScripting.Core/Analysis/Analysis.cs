namespace Unity.VisualScripting
{
    public abstract class Analysis : IAnalysis
    {
    }
}
