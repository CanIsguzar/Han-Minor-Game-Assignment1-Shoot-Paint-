---
title: nodes-single-input
---

node has one input port: