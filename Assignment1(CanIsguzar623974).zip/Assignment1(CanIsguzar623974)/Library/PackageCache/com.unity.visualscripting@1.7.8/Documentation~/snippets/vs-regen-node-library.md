---
title: regen-node-library
---

Follow the process described in [Configure project settings](../vs-configuration.md#Regen) to regenerate your Node Library.
