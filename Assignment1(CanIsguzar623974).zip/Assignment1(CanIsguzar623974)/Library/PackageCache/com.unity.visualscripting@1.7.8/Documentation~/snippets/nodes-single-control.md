---
title: nodes-single-control
---

node has one control: