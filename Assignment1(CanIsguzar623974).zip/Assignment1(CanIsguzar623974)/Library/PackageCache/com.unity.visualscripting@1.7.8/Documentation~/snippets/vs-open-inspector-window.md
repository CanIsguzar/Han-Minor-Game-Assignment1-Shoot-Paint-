---
title: open-inspector-window
---

With the GameObject selected in the Hierarchy window, go to **Window** &gt; **General** &gt; **Inspector**, or press Ctrl+3 (macOS: Cmd+3) to open the [Inspector window](https://docs.unity3d.com/Documentation/Manual/UsingTheInspector.html).