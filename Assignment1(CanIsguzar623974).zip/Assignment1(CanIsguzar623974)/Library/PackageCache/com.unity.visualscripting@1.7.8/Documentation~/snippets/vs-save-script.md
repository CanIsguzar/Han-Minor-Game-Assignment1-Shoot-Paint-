---
title: save-script
---

Save your script file.