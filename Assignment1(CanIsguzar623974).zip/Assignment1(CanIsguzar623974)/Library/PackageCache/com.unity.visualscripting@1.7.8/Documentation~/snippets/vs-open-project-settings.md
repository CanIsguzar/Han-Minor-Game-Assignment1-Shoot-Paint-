---
title: open-project-settings
---

Go to **Edit** &gt; **Project Settings**. 